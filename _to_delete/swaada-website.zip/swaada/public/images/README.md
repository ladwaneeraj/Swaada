# Replacing the placeholder images

Every image on the site is a generated botanical placeholder (SVG).
Replace them with real photographs of Swaada — the layout, hover
effects and optimization all keep working.

How to replace:

1. Drop your photo into this folder, e.g. `hero.jpg`.
2. Open `src/data/swaada.ts` and change the matching path,
   e.g. `"/images/hero.svg"` → `"/images/hero.jpg"`.

Use JPG or WebP. Recommended sizes (width × height, roughly):

| Slot | File | Suggested shot |
|---|---|---|
| Hero background | `hero.svg` (2000×1250) | Wide shot: seating + dense plants + warm light |
| Hero foreground | `hero-foreground.svg` | Optional transparent PNG of foreground leaves (or point both slots at the same photo) |
| Story large | `story-large.svg` (1600×1067) | Café interior with greenery |
| Story small A | `story-small-a.svg` (1000×1250, portrait) | A plant / nursery detail |
| Story small B | `story-small-b.svg` (1000×800) | A dish or coffee |
| Nursery | `nursery.svg` (2000×1200) | Rows of potted plants beside seating |
| Coffee moment | `coffee-moment.svg` (2200×1100) | Close-up coffee, moody light |
| Green Escape | `escape-*.svg` (1200×1600, portrait) | Entrance, plants, seating, café, food, coffee, evening |
| Food cards | `food-*.svg` (1200×900) | One photo per category |
| Gallery | `gallery-*.svg` (portrait for `-1` tall slots) | Mix of café / food / people / evening |
| Instagram grid | `insta-*.svg` (900×900, square) | Square crops |

Photo sources, in order of preference: the owner's own photos of
Swaada, then properly licensed photography. Don't download images
from the Google Maps listing without permission from whoever took
them.
